import java.security.spec.RSAOtherPrimeInfo;
import java.sql.SQLOutput;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
    int age=19; // '=' Assignment operator
    if (age==18){
        System.out.println("Yes you can drive");
    }
    else{
        System.out.println("you cannot drive this");
    }
    }
}